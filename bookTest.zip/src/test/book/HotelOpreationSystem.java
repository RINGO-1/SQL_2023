package test.book;

import java.util.Scanner;

public class HotelOpreationSystem {
	static Scanner scan = new Scanner(System.in);
	static boolean space;	//공실여부	 True : 공실있음 / False : 공실없음
	static boolean empty;	//전체가 비어있는지 확인	True : 전체공실 / False : 입실있음
	static boolean found;	//목표 데이터 발견여부 True : 발견 / False : 미발견
	static String animal_name;	//동물의 이름 입력에 사용할 변수
	static int empty_room_number;	//비어있는 방번호 저장
	static int room_number;	//목표 데이터의 방번호 저장
	static String[] room = new String[2];	//데이터를 저장할 배열선언

	public static void check_in() {
		search(1);
		if (!space) {
			System.out.println("<<< 호텔내 여유 객실 부족 >>>");
			System.out.println("다음에 이용해주세요");
		} else {
			System.out.println("<<< 체크인 >>>");
			System.out.println("<< 체크인하려는 동물의 종을 선택 >>");
			System.out.println("1. 개 // 2. 고양이");

			int choice = scan.nextInt();
			System.out.println("동물의 이름을 입력하세요");
			animal_name = scan.next();

			if (choice == 1) {
				dog d = new dog(animal_name);
				System.out.printf("%s이/가 체크인하였습니다%n", d.name);
				room[empty_room_number] = "dog." + d.name;
			} else if (choice == 2) {
				cat c = new cat(animal_name);
				System.out.printf("%s이/가 체크인하였습니다%n", c.name);
				room[empty_room_number] = "cat." + c.name;
			}
		}

	}

	public static void check_out() {
		search(3);
		if (empty) {
			System.out.println("<<< 사용중인 객실이 없습니다 >>>");
		} else {
			System.out.println("<<< 체크아웃 >>>");
			System.out.println("<< 체크아웃하려는 동물의 이름을 입력 >>");
			animal_name = scan.next();
			search(2);
			if (found) {
				if (room[room_number].contains("cat")) {
					cat c = new cat(animal_name);
					c.meow();
				} else if (room[room_number].contains("dog")) {
					dog d = new dog(animal_name);
					d.bark();
				}
				room[room_number] = "공실";
				System.out.println("<< " + animal_name + " 체크아웃 완료 >>");
				space = true;
			} else {
				System.out.println("<< 대상을 발견하지 못함 >>");
			}
		}
	}

	static void reset() {
		for (int i = 0; i < room.length; i++) {
			room[i] = "공실";
		}
		space = true;
	}

	static void search(int stage) {
		if (stage == 1) {	//체크인 시 사용
			space = false;
			for (int i = 0; i < room.length; i++) {
				if (room[i].contains("공실")) {
					empty_room_number = i;
					space = true;
					break;
				}
			}
		} else if (stage == 2) {	//체크아웃시 사용
			for (int i = 0; i < room.length; i++) {
				found = false;
				if (room[i].contains(animal_name)) {
					room_number = i;
					found = true;
					break;
				}
				
			}
		} else if (stage == 3) {	//전체가 비어있는지 확인할 때
			empty = true;
			for (int i = 0; i < room.length; i++) {
				if (!room[i].contains("공실")) {
					empty = false;
					break;
				}
			}
		}
	}

	static void display() {
		for (int i = 0; i < room.length; i++) {
			System.out.print(" | ");
			System.out.print(room[i]);
			;
		}
		System.out.print(" | ");
	}

	public static void main(String[] args) {
		reset();
		boolean test = true;
		while (test) {
			System.out.println("\n<<< 동물호텔 메인 메뉴 >>>");
			System.out.println("1. 체크인");
			System.out.println("2. 체크아웃");

			int menu_selector = scan.nextInt();
			switch (menu_selector) {
			case 1: {
				check_in();
				break;
			}
			case 2: {
				check_out();
				break;
			}
			case 99: {
				display();
				break;
			}
			case 0: {
				System.out.println("프로그램 종료");
				test = false;
				continue;
			}
			default: {
				System.out.println("잘못된 입력");
				break;
			}
			}
		}
	}
}
