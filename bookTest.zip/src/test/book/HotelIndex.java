package test.book;

class animal {
	String name;

	public animal(String name) {
		this.name = name;
	}
}

class dog extends animal {
	public void bark() {
		System.out.println(name + ": 멍멍");
	}

	public dog(String name) {
		super(name);
	}
}

class cat extends animal {
	public void meow() {
		System.out.println(name + ": 냐옹");
	}

	public cat(String name) {
		super(name);
	}

}